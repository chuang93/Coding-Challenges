Charles Huang (U.S Citizen) -- Software Engineer at Labatt Food Service (cwh21@duke.edu --9/17/2016)

The source code is a text file that you can copy and past into a .java file in your source folder, and will check for a .gz file
of name "yesware-test-data-v1-6.txt gz" in your working project directory. All answers are written to the console.

One assumption I made for the instructions is that the unique count of full names is not of full and completely unique names.
So I in the unique count it will cound "Huang, Charles" and "Huang, Kevin" as two different actors which to me made sense because
An email search might want to located and count these two people. In complete unique list, however, "Huang, Kevin" would not be 
included because the last name "Huang" already appears.

Thanks again for letting me work on this, It was a fun assignment to answer while trying to make it clean, modular and efficient.


-Charles